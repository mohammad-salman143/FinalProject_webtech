-- Create the product table
CREATE TABLE IF NOT EXISTS `product` (
    `ID` INT NOT NULL,
    `Name` VARCHAR(100) NOT NULL,
    `Buy_Price` DECIMAL(10,2) NOT NULL,
    `Sell_Price` DECIMAL(10,2) NOT NULL,
    `image` VARCHAR(255),
    PRIMARY KEY (`ID`)
);


CREATE TABLE IF NOT EXISTS `user_info` (
    `ID` INT NOT NULL AUTO_INCREMENT,
    `Name` VARCHAR(100) NOT NULL,
    `Email` VARCHAR(100) NOT NULL,
    `Dob` DATE NOT NULL,
    `Gender` ENUM('Male', 'Female', 'Other') NOT NULL,
    `User_Name` VARCHAR(50) NOT NULL UNIQUE,
    `Password` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`ID`)
);

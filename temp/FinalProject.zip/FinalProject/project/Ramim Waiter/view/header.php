<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <style>
       
    </style>
    <title>Header Example</title>
</head>

<body>
    <div class="header">
        <p id="nav">
            <b>
                <a href="homepage.php">Home</a>
                <a href="login.php">Login</a>
                <a href="registration.php">Register</a>
                <a href="../../..">Portal</a>
            </b>
        </p>
    </div>
</body>

</html>

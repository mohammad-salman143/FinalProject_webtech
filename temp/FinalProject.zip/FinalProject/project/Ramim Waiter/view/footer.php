<footer class="footer">
    <p>Salman Farul | <a href="mailto:21-44660-1@student.aiub.edu">21-44660-1@student.aiub.edu</a><br> 
       Copyright <span>&#169;</span> 2025</p>
</footer>

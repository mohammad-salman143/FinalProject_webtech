<?php
session_start();

if (isset($_SESSION['username'])) {


} else {

    header('location: login.php');
}

?>








<?php
require_once '../controller/readData.php';
$user = fetchUsers($_SESSION['username']);

?>



<!DOCTYPE html>
<html>
<style>



</style>

<head>
    <title>Profile</title>
</head>

<?php include('header2.php') ?>



<div>
    <div>
        <h1>My Profile</h1>
    </div>
    <div class="editP">
        <div><span>Profile Name:</span> <?php echo htmlspecialchars($user["Name"]); ?></div>
        <div><span>User Name:</span> <?php echo htmlspecialchars($user["User_Name"]); ?></div>
        <div><span>Date of Birth:</span> <?php echo htmlspecialchars($user["Dob"]); ?></div>
        <div><span>Gender:</span> <?php echo htmlspecialchars($user["Gender"]); ?></div>
        <div><span>Email Address:</span> <?php echo htmlspecialchars($user["Email"]); ?></div>
    </div>
</div>

<body>






</body>

<p><br></p>
<?php include('footer.php') ?>

</html>
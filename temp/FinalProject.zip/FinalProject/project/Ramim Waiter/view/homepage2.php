<?php

session_start();


if (isset($_SESSION['username'])) {
} else {

    header('location: login.php');
}

?>






<!DOCTYPE html>


<html lang="en">

<head>
    <title></title>
</head>


<?php include('header2.php') ?>

<body>

<table class="welcome-table">
    <tr>
        <td>
            <h2>WELCOME</h2>
            <h2>TO</h2>
            <h2>Restaurant Management System</h2>
        </td>
    </tr>
</table>

</body>

<?php include('footer.php') ?>

</html>

<?php
session_start();
?>


<!DOCTYPE html>
<html>

 <?php include('header.php')?>




<span style="color: green"> <b> <h1 align="center"><?php echo  "successfully completed ";?></h1> </span>

<body>





</body>
<?php include('footer.php')?>
</html>
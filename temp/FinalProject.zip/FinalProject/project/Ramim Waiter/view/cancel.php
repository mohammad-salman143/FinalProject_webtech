



<?php

    $q=$_GET["q"];
    


    $con = mysqli_connect('localhost','root','','ecommerce');
    if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
    }

    $sql="UPDATE deliver_request SET Status = 'Not Accepted' WHERE ID ='$q'";
    echo '<h1>'.$q.'</h1>';
    $result = mysqli_query($con,$sql);

    
    if($result){
        echo '<h1>deleted</h1>';
        header('location: pending.php');

    }
    
    
    

    mysqli_close($con);

  ?>
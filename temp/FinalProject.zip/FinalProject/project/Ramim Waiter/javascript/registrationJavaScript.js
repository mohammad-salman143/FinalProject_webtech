// Check if password length is at least 6
function checkPasswordLength() {
    var password = document.getElementById("password").value;
    var errorField = document.getElementById("passwordErr");

    if (password.length < 6) {
        errorField.innerHTML = "Password must be at least 6 characters";
    } else {
        errorField.innerHTML = "";
    }
}

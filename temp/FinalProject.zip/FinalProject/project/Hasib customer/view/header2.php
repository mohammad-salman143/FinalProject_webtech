


<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>







<?php
	echo '
	

	<fieldset >

	    <p align="center" id="header2"><b>
	        <a href="homepage2.php" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="myProfile.php" >My Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="editProfile.php" >Update Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="orderFood.php" >Find/Order Food</a>&nbsp;&nbsp;&nbsp;
	        <a href="cartList.php" >Cart List</a>&nbsp;&nbsp;&nbsp;
	        <a href="Logout.php" >Log Out</a>
			
	    </p> 
	    <center><img  src="../uploads/logo.jpg" id="img2"></center>
	</fieldset>



	';

?>
<?php
session_start();

if(isset($_SESSION['username'])){


}
else{

    header('location: login.php');
}

?>



<?php  
    require_once '../controller/readData.php';
    $user = fetchUsers($_SESSION['username']);

?>



<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <style>
        body {
            background: linear-gradient(135deg, #f8fafc 0%, #e0c3fc 100%);
            font-family: 'Segoe UI', Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .profile-card {
            background: #fff;
            max-width: 420px;
            margin: 40px auto 0 auto;
            border-radius: 18px;
            box-shadow: 0 8px 32px 0 rgba(93,0,111,0.12);
            padding: 36px 32px 28px 32px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .profile-card h1 {
            color: #5D006F;
            margin-bottom: 18px;
            font-size: 2rem;
            font-weight: 700;
        }
        .profile-card label {
            color: #394393;
            font-size: 1.1rem;
            margin-bottom: 6px;
            display: block;
            font-weight: 500;
        }
        .profile-card input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            margin-bottom: 8px;
            border: 1.5px solid #d1b3e0;
            border-radius: 7px;
            font-size: 1rem;
            transition: border 0.2s;
            background: #faf7fc;
        }
        .profile-card input[type="text"]:focus {
            border: 1.5px solid #5D006F;
            outline: none;
            background: #fff;
        }
        .profile-card .readonly {
            background: #f0e6fa;
            color: #888;
        }
        .profile-card .info-row {
            width: 100%;
            margin-bottom: 14px;
        }
        .profile-card .info-row span {
            font-size: 1rem;
            color: #5D006F;
            font-weight: 500;
        }
        .profile-card .error2 {
            color: #FF0000;
            font-size: 0.98rem;
            margin-bottom: 8px;
            display: block;
        }
        .profile-card input[type="submit"] {
            background: linear-gradient(90deg, #5D006F 0%, #a4508b 100%);
            color: #fff;
            border: none;
            border-radius: 7px;
            padding: 12px 0;
            width: 100%;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.2s, box-shadow 0.2s;
            box-shadow: 0 2px 8px 0 rgba(93,0,111,0.08);
        }
        .profile-card input[type="submit"]:hover {
            background: linear-gradient(90deg, #a4508b 0%, #5D006F 100%);
        }
        @media (max-width: 500px) {
            .profile-card {
                padding: 18px 8px 18px 8px;
            }
            .profile-card h1 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>

 <?php include('header2.php')?>



 <?php

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $_SESSION['name1'] = $_REQUEST['name'];
        $_SESSION['email1'] = $_REQUEST['email'];
        header('location:../controller/editProfileDone.php');
    }

?>


<body>
    <div class="profile-card">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <h1>Edit Profile</h1>
            <div class="info-row">
                <label for="name">Profile Name</label>
                <input type='text' name='name' value="<?php echo $user["Name"] ?>" id="name">
            </div>
            <div class="info-row">
                <label for="email">Email Address</label>
                <input type='text' name='email' value="<?php echo $user["Email"]?>" id="email">
            </div>
            <div class="info-row">
                <label for="username">User Name</label>
                <input type='text' name='username' value="<?php echo $user["User_Name"] ?>" readonly class="readonly">
            </div>
            <div class="info-row">
                <label>Date of Birth</label>
                <span><?php echo $user["Dob"];?></span>
            </div>
            <div class="info-row">
                <label>Gender</label>
                <span><?php echo $user["Gender"];?></span>
            </div>
            <input type='submit' value='Update'>
        </form>
    </div>
</body>

<script type="text/javascript" src="../javascript/regiPage.js"></script>



<?php include('footer.php')?> 


  </html>
<?php
session_start();

if (isset($_SESSION['username'])) {


} else {

    header('location: login.php');
}

?>



<!DOCTYPE html>
<html>

<?php include('header2.php') ?>

<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: url('../background.jpg') no-repeat center center fixed;
        background-size: cover;
        margin: 0;
        padding: 0;
    }
    .cart-container {
        max-width: 800px;
        margin: 40px auto 0 auto;
        background: rgba(255,255,255,0.92); /* semi-transparent white */
        border-radius: 12px;
        box-shadow: 0 4px 24px rgba(0,0,0,0.08);
        padding: 32px 24px 24px 24px;
    }
    .cart-title {
        text-align: center;
        font-size: 2.2rem;
        color: #2d2d2d;
        margin-bottom: 24px;
        letter-spacing: 1px;
    }
    .cart-list {
        display: flex;
        flex-direction: column;
        gap: 18px;
        margin-bottom: 24px;
    }
    .cart-card {
        display: flex;
        align-items: center;
        background: #f3f6fa;
        border-radius: 8px;
        padding: 16px 20px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        transition: box-shadow 0.2s;
    }
    .cart-card:hover {
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
    }
    .cart-img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 8px;
        margin-right: 20px;
        background: #e0e0e0;
    }
    .cart-info {
        flex: 1;
    }
    .cart-name {
        font-size: 1.1rem;
        font-weight: 600;
        color: #222;
    }
    .cart-qty {
        color: #666;
        font-size: 0.98rem;
        margin-top: 2px;
    }
    .cart-price {
        font-size: 1.1rem;
        color: #1a8917;
        font-weight: 500;
        margin-left: 18px;
    }
    .cart-summary {
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: #eaf6ea;
        border-radius: 8px;
        padding: 14px 20px;
        margin-bottom: 24px;
        font-size: 1.1rem;
        color: #2d2d2d;
    }
    .buy-button {
        background-color: #1a8917;
        color: white;
        padding: 14px 36px;
        font-size: 1.2rem;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        box-shadow: 0 2px 8px rgba(26,137,23,0.12);
        transition: background 0.2s, box-shadow 0.2s;
        display: flex;
        align-items: center;
        gap: 8px;
        margin: 0 auto;
    }
    .buy-button:hover {
        background-color: #156d13;
        box-shadow: 0 4px 16px rgba(26,137,23,0.18);
    }
    .empty-cart {
        text-align: center;
        color: #888;
        font-size: 1.2rem;
        margin: 40px 0;
    }
    @media (max-width: 600px) {
        .cart-container {
            padding: 12px 4px 18px 4px;
        }
        .cart-card {
            flex-direction: column;
            align-items: flex-start;
            gap: 8px;
        }
        .cart-img {
            margin-bottom: 8px;
            margin-right: 0;
        }
        .cart-summary {
            flex-direction: column;
            gap: 6px;
        }
    }
</style>



<body onload="getCartList()">


    <div class="cart-container">
        <div class="cart-title">🛒 Your Cart</div>
       
        <div class="cart-list" id="cartList">
            <!-- Placeholder cart items for demo -->
            <div class="cart-card">
                <img src="../uploads/logo.jpg" class="cart-img" alt="Food Item">
                <div class="cart-info">
                    <div class="cart-name">Chicken Burger</div>
                    <div class="cart-qty">Quantity: 1</div>
                </div>
                <div class="cart-price">$14.99</div>
            </div>
            <div class="cart-card">
                <img src="../uploads/logo.jpg" class="cart-img" alt="Food Item">
                <div class="cart-info">
                    <div class="cart-name">Veggie Pizza</div>
                    <div class="cart-qty">Quantity: 2</div>
                </div>
                <div class="cart-price">$19.99</div>
            </div>
            <!-- If cart is empty, show this -->
            <!-- <div class="empty-cart">Your cart is empty. Add some delicious food!</div> -->
        </div>
        <button class="buy-button"">
            <span>🛍️ Buy Now</span>
        </button>
    </div>

</body>



<script type="text/javascript" src="../javascript/ajax.js">


</script>

<script>
    // Remove showAlert, now handled by buyNow()
    // Optionally, refresh cart summary after purchase in buyNow()
</script>



<br>
<p></p><br><br>
<p></p><br>
<div class="footer">
    <?php include('footer.php') ?>
</div>

</html>
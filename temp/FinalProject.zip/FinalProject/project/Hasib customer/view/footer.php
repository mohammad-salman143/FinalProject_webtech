<?php

	echo "<fieldset><p align=center style=\"color:purple\"> <b>21-44500-1@student.aiub.edu <br>Copyright <span>&#169;</span>2025</p></fieldset>";

?>


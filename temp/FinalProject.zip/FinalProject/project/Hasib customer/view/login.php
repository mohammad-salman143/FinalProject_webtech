<?php
session_start();

if (isset($_POST["submit"])) {
    $_SESSION['username'] = $_REQUEST['username'];
    $_SESSION['password'] = $_REQUEST['password'];
}
?>

<?php
require_once '../controller/readData.php';

if (isset($_REQUEST['username'])) {
    $users = fetchAllUsers($_REQUEST['username']);
}
?>

<!DOCTYPE html>
<html>
<style>
body {
    min-height: 100vh;
    margin: 0;
    padding: 0;
    background: linear-gradient(135deg, #00ab71 0%, #3a7bd5 100%);
    font-family: 'Segoe UI', Arial, sans-serif;
    display: flex;
    flex-direction: column;
}
.centered-form {
    flex: 1 0 auto;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 80vh;
}
form fieldset {
    background: rgba(255,255,255,0.98);
    border-radius: 20px;
    box-shadow: 0 4px 24px 0 rgba(31, 38, 135, 0.12);
    border: 1px solid #e0e0e0;
    padding: 2.2rem 2rem 2rem 2rem;
    max-width: 340px;
    width: 100%;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 0.5rem;
}
form h1 {
    color: #00ab71;
    margin-bottom: 1.2rem;
    font-size: 1.5rem;
    letter-spacing: 1px;
    font-weight: 700;
    text-align: center;
}
.form-group {
    display: flex;
    flex-direction: column;
    margin-bottom: 0.7rem;
}
form label, form b {
    color: #333;
    font-size: 1rem;
    font-weight: 500;
    margin-bottom: 0.2rem;
    text-align: left;
}
form input[type="text"],
form input[type="password"] {
    width: 100%;
    padding: 0.55rem 0.9rem;
    margin: 0;
    border: 1.2px solid #e0e0e0;
    border-radius: 7px;
    background: #f7f7f7;
    font-size: 1rem;
    transition: border 0.2s, box-shadow 0.2s;
    box-sizing: border-box;
}
form input[type="text"]:focus,
form input[type="password"]:focus {
    border: 1.2px solid #00ab71;
    outline: none;
    background: #fff;
    box-shadow: 0 0 0 2px #00ab7133;
}
form .error {
    color: #ff3b3b;
    font-size: 0.93rem;
    margin-top: 0.1rem;
    margin-bottom: 0.1rem;
    min-height: 1.1em;
    text-align: left;
}
.checkbox-group {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1.2rem;
    margin-top: 0.2rem;
}
form input[type="checkbox"] {
    accent-color: #00ab71;
    width: 1.1em;
    height: 1.1em;
    margin: 0;
}
form input[type="submit"] {
    width: 100%;
    background: linear-gradient(90deg, #00ab71 60%, #3a7bd5 100%);
    color: #fff;
    border: none;
    border-radius: 7px;
    padding: 0.7rem 0;
    font-size: 1.08rem;
    font-weight: 700;
    cursor: pointer;
    box-shadow: 0 2px 8px rgba(58, 123, 213, 0.08);
    transition: background 0.2s, transform 0.1s;
    margin-top: 0.2rem;
    margin-bottom: 0.2rem;
}
form input[type="submit"]:hover {
    background: linear-gradient(90deg, #009e66 60%, #2e5fa7 100%);
    transform: translateY(-1px) scale(1.01);
}
.footer {
    flex-shrink: 0;
    width: 100%;
    background: rgba(255,255,255,0.98);
    color: #222;
    text-align: center;
    padding: 0.7rem 0 0.4rem 0;
    font-size: 0.98rem;
    border-top: 1.2px solid #e0e0e0;
    box-shadow: 0 -2px 12px 0 rgba(31, 38, 135, 0.06);
    position: relative;
    z-index: 2;
}
@media (max-width: 480px) {
    form fieldset {
        padding: 1.1rem 0.4rem 1.1rem 0.4rem;
        max-width: 98vw;
    }
    form h1 {
        font-size: 1.15rem;
    }
    .footer {
        font-size: 0.93rem;
        padding: 0.5rem 0 0.2rem 0;
    }
}
</style>

<head>
    <title>Login</title>
</head>

<?php include('header.php'); ?>

<?php
$username = $password = "";
$usernameErr = $passwordErr = "";
$check = $flag = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Simplified username validation: only check if empty
    if (empty($_POST["username"])) {
        $usernameErr = "Username is required";
    } else {
        $username = test_input($_POST["username"]);
        $check++;
    }

    // Simplified password validation: only check if empty
    if (empty($_POST["password"])) {
        $passwordErr = "Password is required";
    } else {
        $password = test_input($_POST["password"]);
        $check++;
    }

    if ($check == 2) {
        $_SESSION['username'] = $_REQUEST['username'];
        $_SESSION['password'] = $_REQUEST['password'];

        foreach ($users as $row) {
            if ($_SESSION['username'] == $row["User_Name"] && $_SESSION['password'] == $row["Password"]) {
                $flag = 1;
                if (!empty($_POST["remember"])) {
                    setcookie("username", $_POST["username"], time() + 2000);
                    setcookie("password", $_POST["password"], time() + 2000);
                    echo "<h1>Cookies Set Successfuly</h1>";
                } else {
                    setcookie("username", "");
                    setcookie("password", "");
                    echo "<h1>Cookies Not Set</h1>";
                }
                header('location:../view/homepage2.php');
            } else {
                $flag = 0;
            }
        }

        if ($flag == 0)
            echo '<h2 style="color: red;" align="center" >Error Password and login fail </h2>';
    }
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<body>
<div class="centered-form">
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
  <fieldset>
    <h1>LOGIN</h1>
    <div class="form-group">
      <label for="userName">User Name</label>
      <input type="text" id="userName" name="username" value="<?php if (isset($_COOKIE["username"])) { echo $_COOKIE["username"]; } ?>" required onkeyup="userVal()">
      <span id="usernameErr" class="error">* <?php echo $usernameErr; ?></span>
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <input type="password" id="password" name="password" value="<?php if (isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>" required onkeyup="passVal()">
      <span id="passwordErr" class="error">* <?php echo $passwordErr; ?></span>
    </div>
    <div class="checkbox-group">
      <input type="checkbox" id="remember" name="remember" value="remember">
      <label for="remember" style="margin-bottom:0;">Remember me</label>
    </div>
    <input type="submit" name="submit" value="Login">
  </fieldset>
</form>
</div>
</body>

<script type="text/javascript" src="../javascript/loginPage.js"></script>

<div class="footer">
    <?php include('footer.php')?> 
</div>
</html>

<?php
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <style>.error {color: #FF0000;}</style>
</head>

<?php include('header.php'); ?>

<?php
  $nameErr = $emailErr = $genderErr = $birthdateErr = $newpassErr = $renewpassErr = $usernameErr = "";
  $name = $email = $gender = $birthdate = $newpass = $renewpass = $username = "";
  $check = 0;

  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if (empty($_POST["name"])) {
      $nameErr = "Name is required";
    } else {
      $name = $_POST["name"];
      $check++;
    }

    if (empty($_POST["email"])) {
      $emailErr = "Email is required";
    } else {
      $email = $_POST["email"];
      $check++;
    }

    if (empty($_POST["username"])) {
      $usernameErr = "Username is required";
    } else {
      $username = $_POST["username"];
      $check++;
    }

    if (empty($_POST["newpass"])) {
      $newpassErr = "Password is required";
    } else {
      $newpass = $_POST["newpass"];
      if (strlen($newpass) < 6) {
        $newpassErr = "Password must be at least 6 characters";
      } else {
        $check++;
      }
    }

    if (empty($_POST["renewpass"])) {
      $renewpassErr = "Confirm Password is required";
    } else {
      $renewpass = $_POST["renewpass"];
      if ($newpass !== $renewpass) {
        $renewpassErr = "Passwords do not match";
      } else {
        $check++;
      }
    }

    if (empty($_POST["birthdate"])) {
      $birthdateErr = "Date of Birth is required";
    } else {
      $birthdate = $_POST["birthdate"];
      $check++;
    }

    if (empty($_POST["gender"])) {
      $genderErr = "Gender is required";
    } else {
      $gender = $_POST["gender"];
      $check++;
    }

    if ($check == 7) {
      $_SESSION['name'] = $name;
      $_SESSION['email'] = $email;
      $_SESSION['username'] = $username;
      $_SESSION['pass'] = $newpass;
      $_SESSION['dob'] = $birthdate;
      $_SESSION['gender'] = $gender;
      header('location:../controller/registrationDone.php');
    }
  }
?>

<body>
  <fieldset>
    <center>
      <h1 style="color: #00AB71;">Registration</h1>
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <span class="error">(*) required</span><br><br>

        <b>Name:</b>
        <input type="text" name="name" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["name"])) echo "Name is required"; ?></span><br><br>

        <b>Email:</b>
        <input type="text" name="email" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["email"])) echo "Email is required"; ?></span><br><br>

        <b>Username:</b>
        <input type="text" name="username" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["username"])) echo "Username is required"; ?></span><br><br>

        <b>Password:</b>
        <input type="password" name="newpass" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["newpass"])) echo "Password is required"; ?></span><br><br>

        <b>Confirm Password:</b>
        <input type="password" name="renewpass" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["renewpass"])) echo "Confirm Password is required"; ?></span><br><br>

        <b>Date of Birth:</b>
        <input type="date" name="birthdate" required><br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["birthdate"])) echo "Date of Birth is required"; ?></span><br><br>

        <b>Gender:</b>
        <input type="radio" name="gender" value="female" required>Female
        <input type="radio" name="gender" value="male">Male
        <input type="radio" name="gender" value="other">Other<br>
        <span class="error">* <?php if($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["gender"])) echo "Gender is required"; ?></span><br><br>

        <input type="submit" value="Submit"><br><br>
      </form>
    </center>
  </fieldset>
</body>

<script type="text/javascript" src="../javascript/regiPage.js"></script>

<div class="footer">
  <?php include('footer.php'); ?> 
</div>
</html>

<?php
    $con = mysqli_connect('localhost', 'root', '', 'restaurant');
    if (!$con) {
        die('Could not connect: ' . mysqli_error($con));
    }

    $sql = "SELECT * FROM `product`";
    $result = mysqli_query($con, $sql);

    echo '<table align="center" border="1" cellpadding="10" id="foodTable2">
    <tr>
        <th>ID</th>
        <th>Food Name</th>
        <th>Sell Price</th>
        <th>Action</th>
    </tr>';

    while ($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        echo "<td>" . $row['ID'] . "</td>";
        echo "<td>" . $row['Name'] . "</td>";
        echo "<td>" . $row['Sell_Price'] . "</td>";

        $name = $row['Name'];
        $price = $row['Sell_Price'];

        echo '<td><button onclick="addCart(\'' . $name . '\', \'' . $price . '\')">Add to Cart</button></td>';
        echo "</tr>";
    }

    echo "</table>";

    mysqli_close($con);
?>

<?php
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['username'])) {
    echo json_encode(['success' => false, 'message' => 'Not logged in']);
    exit;
}
$username = $_SESSION['username'];
require_once('../model/db_connect.php');
$conn = db_conn();

// Get cart items for this user
try {
    $stmt = $conn->prepare('SELECT * FROM cart_list WHERE username = ?');
    $stmt->execute([$username]);
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$cartItems || count($cartItems) === 0) {
        echo json_encode(['success' => false, 'message' => 'Cart is empty']);
        exit;
    }
    $totalPrice = 0;
    foreach ($cartItems as $item) {
        $totalPrice += floatval($item['price']) * intval($item['quantity']);
    }
    // Save order
    $orderData = [
        'username' => $username,
        'items' => json_encode($cartItems),
        'total_price' => $totalPrice,
        'order_date' => date('Y-m-d H:i:s')
    ];
    // Create orders table if not exists
    $conn->exec('CREATE TABLE IF NOT EXISTS orders (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255),
        items TEXT,
        total_price DECIMAL(10,2),
        order_date DATETIME
    )');
    $stmt = $conn->prepare('INSERT INTO orders (username, items, total_price, order_date) VALUES (?, ?, ?, ?)');
    $stmt->execute([$orderData['username'], $orderData['items'], $orderData['total_price'], $orderData['order_date']]);
    // Delete all cart items for this user
    $stmt = $conn->prepare('DELETE FROM cart_list WHERE username = ?');
    $stmt->execute([$username]);
    echo json_encode(['success' => true, 'message' => 'Order placed successfully']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} 
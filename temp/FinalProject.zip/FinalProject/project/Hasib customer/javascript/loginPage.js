function userVal() {
    var userName = document.getElementById("userName").value;
    if (userName === "") {
        document.getElementById("usernameErr").innerHTML = "Username is required";
    } else {
        document.getElementById("usernameErr").innerHTML = "";
    }
}

function passVal() {
    var password = document.getElementById("password").value;
    if (password === "") {
        document.getElementById("passwordErr").innerHTML = "Password is required";
    } else {
        document.getElementById("passwordErr").innerHTML = "";
    }
}
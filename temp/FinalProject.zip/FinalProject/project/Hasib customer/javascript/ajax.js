function getAll() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("foodList").innerHTML = this.responseText;
        }
    };
    xmlhttp.open("GET", "../controller/getAllFood.php?", true);
    xmlhttp.send();
    return;
}





function showResult(str) {

    if (str.length == 0) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("foodList").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "../controller/getAllFood.php?", true);
        xmlhttp.send();
        return;
    } else {

        document.getElementById("foodList").innerHTML = "";
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("foodList").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET", "../controller/getFood.php?q=" + str, true);
        xmlhttp.send();
    }
}

function addCart(strName, strPrice) {
    alert("Added to cart");

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("foodList").innerHTML = "checj";
            getAll();
        }
    };
    xmlhttp.open("GET", "../controller/addCartDone.php?q=" + strName + "&q2=" + strPrice, true);
    xmlhttp.send();




}



function getCartList() {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("cartList").innerHTML = this.responseText;
        }
    };
    xmlhttp.open("GET", "../controller/getCartList.php?", true);
    xmlhttp.send();
    return;
}


function deleteCart(str) {

    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("cartList").innerHTML = this.responseText;
            getCartList();
        }
    };
    xmlhttp.open("GET", "../controller/deleteDone.php?q=" + str, true);
    xmlhttp.send();


}

function buyNow() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            try {
                var res = JSON.parse(this.responseText);
                if (res.success) {
                    document.getElementById("cartList").innerHTML = '<div class="empty-cart">Your order has been placed! Thank you.</div>';
                    // Optionally, refresh cart summary or other UI here
                } else {
                    alert(res.message || "Order failed.");
                }
            } catch (e) {
                alert("Unexpected response from server.");
            }
        }
    };
    xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xmlhttp.send();
}
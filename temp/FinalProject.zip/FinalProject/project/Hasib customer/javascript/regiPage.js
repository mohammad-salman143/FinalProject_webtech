function passVal() {
  var password = document.getElementById("password").value;
  if (password.length < 6) {
    document.getElementById("passwordErr").innerHTML =
      "Password must be at least 6 characters";
  } else {
    document.getElementById("passwordErr").innerHTML = "";
  }
}

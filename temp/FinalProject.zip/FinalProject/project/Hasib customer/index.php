<?php 
	
	
header('location:view/homepage.php');


?>
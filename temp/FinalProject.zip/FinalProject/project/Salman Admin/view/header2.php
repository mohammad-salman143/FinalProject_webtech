



<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>

<?php
	echo '
	

	

	    
	    <center><img  width="230" height="200" src="../images/bestchoice.jpg" ></center>
	    <h1 align="center">Restaurant Management System</h1>
	    <b>
	    <p align="center" id="header2">
	        <a href="homepage2.php">Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="addEmp.php"  >Add Employee</a>&nbsp;&nbsp;&nbsp;
	        <a href="showEmp.php" >Show/Delete Employee</a>&nbsp;&nbsp;&nbsp;
	        <a href="profile.php" >Profile</a>&nbsp;&nbsp;&nbsp;
	        <a href="logout.php"  >Log Out</a>
	    </p>
	    </b> 
	    
	<hr/>
	';

?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header('location: login.php');
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Profile</title>
    <style>
        .error {color: #FF0000;}
    </style>
</head>

<?php include('header2.php') ?>

<?php
$nameErr = $emailErr = $genderErr = $birthdateErr = $newpassErr = $renewpassErr = $usernameErr = "";
$name = $email = $gender = $birthdate = $newpass = $renewpass = $username = "";
$msg = "";
$check = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["name"])) {
        $nameErr = "Name is required";
    } else {
        $name = test_input($_POST["name"]);
        $check++;
    }

    if (empty($_POST["email"])) {
        $emailErr = "Email is required";
    } else {
        $email = test_input($_POST["email"]);
        $check++;
    }

    if (empty($_POST["username"])) {
        $usernameErr = "Username is required";
    } else {
        $username = test_input($_POST["username"]);
        $check++;
    }

    if (empty($_POST["newpass"])) {
        $newpassErr = "Password is required";
    } else {
        $newpass = test_input($_POST["newpass"]);
        $check++;
    }

    if (empty($_POST["renewpass"])) {
        $renewpassErr = "Confirm Password is required";
    } else {
        $renewpass = test_input($_POST["renewpass"]);
        $check++;
    }

    if ($newpass !== $renewpass) {
        $renewpassErr = "Passwords do not match";
        $check--;
    }

    if (empty($_POST["gender"])) {
        $genderErr = "Gender is required";
    } else {
        $gender = test_input($_POST["gender"]);
        $check++;
    }

    if (empty($_POST["birthdate"])) {
        $birthdateErr = "Birthdate is required";
    } else {
        $birthdate = test_input($_POST["birthdate"]);
        $check++;
    }

    if ($check == 7) {
        require_once '../model/model.php';

        $data = [
            'Name'       => $name,
            'Email'      => $email,
            'Gender'     => $gender,
            'Dob'        => $birthdate,
            'User Name'  => $username,
            'Password'   => $newpass,
        ];

        if (addEmployee($data)) {
            header('location:../view/addEmployeeDone.php');
        } else {
            echo 'You are not allowed to access this page.';
        }
    }
}

function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}
?>

<body>
    <h1 align='center'>Add Employee <br><span class="error"><?php echo $msg; ?></span></h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <table border="3px" align="center">
            <tr>
                <td>Profile Name :</td>
                <td><input type='text' name='name'></td>
                <td><span class="error">* <?php echo $nameErr; ?></span></td>
            </tr>

            <tr>
                <td>User Name :</td>
                <td><input type='text' name='username'></td>
                <td><span class="error">* <?php echo $usernameErr; ?></span></td>
            </tr>

            <tr>
                <td>Password :</td>
                <td><input type='password' name='newpass'></td>
                <td><span class="error">* <?php echo $newpassErr; ?></span></td>
            </tr>

            <tr>
                <td>Retype Password :</td>
                <td><input type='password' name='renewpass'></td>
                <td><span class="error">* <?php echo $renewpassErr; ?></span></td>
            </tr>

            <tr>
                <td>Email :</td>
                <td><input type='text' name='email'></td>
                <td><span class="error">* <?php echo $emailErr; ?></span></td>
            </tr>

            <tr>
                <td>D.O.B :</td>
                <td><input type="date" name="birthdate" min="1953-01-01" max="1998-12-31"></td>
                <td><span class="error">* <?php echo $birthdateErr; ?></span></td>
            </tr>

            <tr>
                <td>Gender :</td>
                <td>
                    <input type="radio" name="gender" value="female">Female
                    <input type="radio" name="gender" value="male">Male
                    <input type="radio" name="gender" value="other">Other
                </td>
                <td><span class="error">* <?php echo $genderErr; ?></span></td>
            </tr>
        </table>
        <h2 align="center"><input type='submit' value='Add'></h2>
    </form>
</body>

<script type="text/javascript" src="../javascript/registrationJavaScript.js"></script>
<?php include('footer.php') ?>
</html>

<?php
session_start();

$nameErr = $emailErr = $genderErr = $birthdateErr = $newpassErr = $renewpassErr = $usernameErr = "";
$name = $email = $gender = $birthdate = $newpass = $renewpass = $username = "";
$check = 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  function test_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
  }

  // Name
  if (empty($_POST["name"])) {
    $nameErr = "Name is required";
  } else {
    $name = test_input($_POST["name"]);
    $check++;
  }

  // Email
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
    $check++;
  }

  // Username
  if (empty($_POST["username"])) {
    $usernameErr = "Username is required";
  } else {
    $username = test_input($_POST["username"]);
    $check++;
  }

  // Password
  if (empty($_POST["newpass"])) {
    $newpassErr = "Password is required";
  } else {
    $newpass = test_input($_POST["newpass"]);
    if (strlen($newpass) < 6) {
      $newpassErr = "Password must be at least 6 characters";
    } else {
      $check++;
    }
  }

  // Confirm Password
  if (empty($_POST["renewpass"])) {
    $renewpassErr = "Confirm Password is required";
  } else {
    $renewpass = test_input($_POST["renewpass"]);
    if ($newpass !== $renewpass) {
      $renewpassErr = "Passwords do not match";
    } else {
      $check++;
    }
  }

  // Birthdate
  if (empty($_POST["birthdate"])) {
    $birthdateErr = "Birthdate is required";
  } else {
    $birthdate = test_input($_POST["birthdate"]);
    $check++;
  }

  // Gender
  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
    $check++;
  }

  if ($check == 7) {
    $_SESSION['name'] = $name;
    $_SESSION['email'] = $email;
    $_SESSION['username'] = $username;
    $_SESSION['pass'] = $newpass;
    $_SESSION['dob'] = $birthdate;
    $_SESSION['gender'] = $gender;
    header('location:../controller/registrationDone.php');
  }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Registration</title>
  <style>
    .error { color: red; }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<center>
  <h1>Sign Up</h1>
  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <span class="error">* Required fields</span><br><br>

    <b>Name:</b>
    <input type="text" id="name" name="name" required><br>
    <span class="error" id="nameErr">* <?php echo $nameErr; ?></span><br><br>

    <b>Email:</b>
    <input type="email" id="email" name="email" required><br>
    <span class="error" id="emailErr">* <?php echo $emailErr; ?></span><br><br>

    <b>Username:</b>
    <input type="text" id="username" name="username" required><br>
    <span class="error" id="usernameErr">* <?php echo $usernameErr; ?></span><br><br>

    <b>Password:</b>
    <input type="password" id="password" name="newpass" required onkeyup="passVal()"><br>
    <span class="error" id="passwordErr">* <?php echo $newpassErr; ?></span><br><br>

    <b>Confirm Password:</b>
    <input type="password" id="rePassword" name="renewpass" required><br>
    <span class="error" id="rePasswordErr">* <?php echo $renewpassErr; ?></span><br><br>

    <b>Date of Birth:</b>
    <input type="date" id="birthdate" name="birthdate" required><br>
    <span class="error" id="birthdateErr">* <?php echo $birthdateErr; ?></span><br><br>

    <b>Gender:</b>
    <input type="radio" name="gender" value="female" required> Female
    <input type="radio" name="gender" value="male"> Male
    <input type="radio" name="gender" value="other"> Other<br>
    <span class="error" id="genderErr">* <?php echo $genderErr; ?></span><br><br>

    <input type="submit" value="Submit"><br><br>
  </form>
</center>

<script src="../javascript/registrationJavaScript.js"></script>

<?php include('footer.php'); ?>

</body>
</html>

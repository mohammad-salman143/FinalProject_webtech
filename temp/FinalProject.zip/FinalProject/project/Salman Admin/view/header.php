

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/styles.css">
    <title></title>
</head>





<?php
	echo '
	

	

	    
	    <center><img  width="280" height="220" src="../images/logo.jpg" ></center> 
	    <h1 align="center">Restaurant Management System</h1> 
	    <p align="center" id="header1" >
	        <a href="homepage.php" >Home</a>&nbsp;&nbsp;&nbsp;
	        <a href="login.php" >Login</a>&nbsp;&nbsp;&nbsp;
	        <a href="registration.php" >Register</a>&nbsp;&nbsp;&nbsp;
	        <a href="contact.php"  >Contact US</a>&nbsp;&nbsp;&nbsp;
			<a href="../../..">Portal</a>
	    </p> 
	<hr/>
	';

?>